---
name: design-experience
description: Use when an approved product brief must become an approval-ready experience specification.
---

# Design Experience

Turn an approved product brief into a clear experience specification that can be reviewed, approved, and handed to planning.

## Use When

- The product brief is approved and the next step is experience definition.
- You need journeys, information architecture, screen inventory, and state coverage.
- You need a traceable spec that links requirements to the proposed experience.
- You need a lightweight prototype outline, not production UI.

## Do Not Use When

- The product brief is still open, drafted, or disputed.
- You need backend architecture, data modeling, or infrastructure choices.
- You need a frontend framework decision or production UI implementation.
- You need deployment, release orchestration, or self-approval.

## Prerequisite

Start only after an approved product brief exists. Verify that the approval evidence names the exact current brief path and revision; an active editor, another URI, a prior revision, or a current phase does not transfer it. If the brief is not approved, stop and return that gap instead of inventing
experience decisions.

The brief should provide, at minimum:

- problem statement and intended outcome;
- target users and primary job;
- scope boundaries and exclusions;
- approved readiness target and architecture shape, including prototype limits or production-ready auth, persistence, staff authorization, and payment boundaries;
- requirement IDs or a clear source of truth for them;
- known constraints, risks, and dependencies.

## Working Rules

1. Read the approved product brief before writing the spec.
2. Keep the experience aligned to the brief, not to personal taste.
3. Do not choose backend architecture or production implementation details.
4. Trace each meaningful experience decision to requirement IDs.
5. Include happy, loading, empty, error, permission, and destructive states.
6. Keep the prototype lightweight enough to validate the experience only.
7. Do not mark the work approved. Human approval is required.
8. Do not allow UI planning to proceed until the Visual Direction Contract has an explicit approval from its named human approval owner.
9. Preserve the independent approved readiness target and architecture shape. A prototype experience must state its demo limits and cannot be presented as production-ready behavior; a full-stack experience must expose the UX implications of backend, shared data, staff authorization, and real-payment
   decisions without choosing their implementation. A restrained visual direction never selects a technology stack.

For an authenticated production-ready full-stack experience, define separate `User` and `Staff` journeys before planning privileged screens. The public journey may contain only the approved catalog, login, and registration surfaces; registration must never offer a Staff-role choice. Define
authenticated User core operations (such as creating/cancelling orders, bookings, or managing personal resources) and session-expiry/logout states, plus Staff/Admin operational, settlement, and revenue permission states when those obligations are in scope. The experience must show a clear
unauthenticated recovery path and a non-disclosing permission or not-found outcome for another user's resource. Do not represent a rendered staff screen, a hidden menu item, or a successful public API response as authorization evidence.

## Curated UX Filter

Use this compact filter while shaping the experience spec.

- Sort every notable choice into evidence, unknown, filler, or validation.
- Evidence stays only when it is tied to the approved brief, research, content, analytics, constraints, or approved assets.
- Unknowns stay explicit. If a choice is not known, mark it as an open question instead of inventing it.
- Filler gets removed. Skip generic layout, decorative treatments, claims, or copy that does not help the task.
- Validation needs a check. If a choice needs proof, say how the prototype or review will test it.
- Pass the UX purpose test. If a screen element does not help task completion, wayfinding, trust, or feedback, leave it out.
- Write one sentence that states the design direction before detailing the rest.
- Give reasons for major design decisions.
- Build the composition from content and task flow, not from a clone-like template.
- Show observable feedback and state changes for hover, focus, selection, loading, success, empty, error, disabled, and destructive states.
- Use real identity assets when approved. If they are not available, call out honest placeholders.
- On small screens, reflow content instead of shrinking everything.
- Keep contrast, keyboard access, visible focus, and reduced motion checks explicit.
- Use restrained motion only when it clarifies feedback or transition.
- **Anti-Slop Hard Gates & Anti-UI Sameness Mandate (Ban Generic AI Slop):**
    1. **Strictly Ban "Card Soup":** Forbid wrapping every section, metric, and list item in uniform rounded white boxes (`bg-white rounded-xl shadow border border-gray-100`). Mandate content-driven compositional grammar: use divided lists with subtle borders, borderless grouped sections with varied
       background values, full-bleed split panes, asymmetric layouts, or editorial typographic hierarchy instead of endless nesting in floating card containers.
    2. **Strictly Ban Uninspired Default Fonts:** Forbid uncritical fallback to default system fonts or plain Inter/Roboto as the sole typographic identity. Mandate an intentional Type Pairing: a distinctive Display/Heading font that captures the product's brand archetype (e.g. geometric sans,
       editorial serif, high-density mono, or grotesque sans) paired with a clean, highly readable Body font.
    3. **Strictly Ban Cliché AI Gradients & Glassmorphism:** Forbid unmotivated purple-to-cyan, indigo-to-violet linear gradients, neon glowing borders, and blurry frosted glass containers that serve no navigational or informational purpose. Color must have functional meaning and express the
       product's brand personality.
    4. **Strictly Ban Cookie-Cutter Template Clichés:** Forbid generic 3-card marketing feature grids on operational pages, centered marketing hero banners with dual pill buttons in app views, and cookie-cutter 4-metric top dashboard cards. Build compositions organically from the real task flow and
       user data density needs.
    5. **Bespoke Semantic Color Palette:** Forbid copying default Tailwind/Bootstrap color presets (e.g. standard blue-600/indigo-600 buttons on gray-100). Generate a tailored semantic color system (primary, secondary, surface, canvas, border, text hierarchy, status) that aligns with the brand
       personality discovered in `discover-product`.
    6. **Mandatory Signature Design Element:** Every visual contract must define at least one concrete `signature_moment` (e.g. a unique summary bar, bespoke tab switch indicator, brand-tailored status badge, or high-density ledger layout) that breaks UI monoculture and makes the application immediately recognizable.
    7. **Mathematical WCAG AA Contrast Verification:** Text on background must strictly pass WCAG AA standards: minimum 4.5:1 for normal body text and 3.0:1 for large text (18px+). Run the deterministic contrast tool (`python scripts/contrast-check.py "<fg_hex>" "<bg_hex>"`) on all palette combinations. Never assume or eyeball contrast; gray-on-gray or low-contrast muted labels are strictly rejected.
    8. **Responsive Mobile Reflow Mandate:** Mobile layout is an intentionally designed reflow state, NOT a desktop layout squeezed into a phone viewport.
       - Implement deliberate 3-state reflow: single reflowing stack (mobile), intermediate two-column grid (tablet), and full multi-column layout (desktop).
       - Use fluid typography with `clamp()` and mobile-scaled padding/rhythms.
       - Use dynamic viewport units (`dvh` or `auto`), never bare `100vh` sections that break mobile browser chrome.
       - Zero Horizontal Scroll Leak: Ensure no container, table, code block, or preformatted string causes horizontal scrolling at 375px viewport width.
    9. **Anti-Slop Copywriting & Product Prose:** All interface copy, empty states, headlines, and CTAs must be crafted for humans, not generated by AI defaults.
       - Strictly FORBIDDEN vocabulary: *unlock, elevate, empower, delve, showcase, seamless, next-level, game-changer, revolutionary, robust, landscape*.
       - Strictly FORBIDDEN patterns: Significance inflation (*"the future of...", "ushering in a new era..."*), weasel attributions (*"experts say..."*), chatbot conversational artifacts (*"I hope this helps!", "Let me know..."*), and fake-candid openers (*"Honestly? Here's the thing..."*).
       - Enforce plain, honest, active-voice microcopy describing the actual user action.
- Accept or reject each notable visual choice according to product purpose, content, user tasks, and operating context; record the product-specific reason either way in `rejected_defaults`.
- Treat restrained operational design as valid and distinctive when deliberate density, hierarchy, typography, navigation, or wayfinding gives it a clear product-specific character without relying on generic template crutches.

Attribution note: this filter is curated from anti-slop v3.2.4 commit 44be68777e96d53d113edad33dbc4ab380f5d054 under MIT. See `THIRD_PARTY_NOTICES.md`.

This skill MUST physically create two contract documents in the `<project-root>/docs/` directory. **Every document is a binding contract, NOT an outline or draft stub. Writing placeholder statements such as "akan diisi nanti", "saat ini kosong", or generating fewer than 30 substantive lines is strictly prohibited.**

1. `docs/03_user_journeys.md`:
   - Detailed step-by-step actor flows for every user persona and staff role.
   - Comprehensive journey coverage: Happy path, Edge cases, Failure & Recovery paths (e.g., failed payment, out-of-stock reserve, expired session).
   - Bespoke Visual Direction Contract (VDC): Color palette with exact hex codes, typography pairing (display + body font), spacing scale, bespoke signature moment, and explicitly rejected generic AI defaults (e.g. no rounded card soup, no generic purple gradients).

2. `docs/07_core_workflows.md`:
   - Complete Screen Inventory with unique IDs (`SCR-001`, `SCR-002`, ...).
   - Layout grammar and component hierarchy for every screen.
   - Exhaustive State Coverage: Loading state, Empty state, Populated state, Error state, and Destructive action confirmation state for every view.
   - Navigation architecture: Strict prevention of the "Frankenstein page" anti-pattern by splitting disparate journeys into distinct routes, tabs, or contextual drawers. Non-blocking secondary actions.

## Artifact Root Contract

`karsa-orchestrator` resolves `<project-root>` before this specialist starts. Every lifecycle artifact path in this contract is project-relative: resolve `artifacts/...` as `<project-root>/artifacts/...`, including visual proof target paths. Keep the existing `output_path` value in the
`fullstack-skill-handoff/v1` block unchanged as a relative `artifacts/...` path. Never write lifecycle artifacts to the plugin installation or repository, or to an unrelated current working directory. If bootstrap did not supply a root, STOP for bootstrap; do not independently infer a root or ask a
second location question.

The spec should be concise, reviewable, and ready for approval.

## Required Spec Content

### 1. Summary

- product name or initiative name;
- approved brief reference;
- scope in one short paragraph;
- out of scope items;
- confirmed readiness target and architecture shape, including prototype demo limitations or the full-stack behaviors that the experience must cover;
- experience status.

### 2. Visual Direction Contract

Define one complete, product-specific Visual Direction Contract inside the experience spec before UI planning begins. The contract owns visual direction for the artifact and must be internally consistent with the approved brief, journeys, states, responsive behavior, and accessibility guidance.

Use these canonical fields:

- `visual_contract_revision`: a unique, immutable revision ID in `VDC-NNN` format, where `NNN` is a three-digit decimal number;
- `visual_approval_owner`: the named human owner responsible for explicit visual approval;
- `direction_mode`: `restrained` or `expressive`, selected according to product purpose rather than aesthetic preference;
- `product_specific_rationale`: why this direction fits the product, users, tasks, content, and operating context;
- `provenance`: the evidence, research, approved assets, constraints, and comparison references that informed the direction, including source and allowed use;
- `validation_widths`: product-approved validation widths in CSS pixels, or the fallback widths 375, 768, and 1280 CSS px when the product defines none;
- `visual_decisions`: an ordered set of decisions, each with a unique `VIS-NNN` ID within the revision, where `NNN` is a three-digit decimal number.

Each entry in `visual_decisions` must include:

- `id`;
- `typography`;
- `color`;
- `spacing_and_density`;
- `layout_grammar`;
- `material_and_surface_language`;
- `component_anatomy`;
- `imagery_and_iconography`;
- `motion`;
- `responsive_intent`;
- `accessibility`;
- `states`;
- `signature_moment`;
- `rejected_defaults`, with a product-specific reason for every rejection.

Make every visual decision concrete enough for planning and validation. The `signature_moment` identifies the product-specific visual or interaction expression that makes the experience recognizable; it may be quiet and operational in a restrained direction. A restrained contract can be distinctive
through deliberate density, hierarchy, typography, navigation, or wayfinding and does not need gradients, glass, animation, or an expressive aesthetic.

Use `none` or `not-applicable` only when the relevant field includes a product-specific rationale. Do not use either value to avoid a decision, state, responsive case, or accessibility obligation.

Treat references only as provenance and comparison inputs. They never grant permission to clone a product, imitate a named brand, copy protected assets, or reuse material without an appropriate license or approval.

Validate the contract, its visual decisions, signature moment, relevant states, responsive intent, and accessibility at every product-approved validation width. If no widths have been approved, validate at 375, 768, and 1280 CSS px. Record what was checked, the result, and any unresolved
inconsistency.

Downstream work must cite a visual decision with the canonical reference `experience-spec@VDC-NNN#VIS-NNN`, where each `NNN` is a three-digit decimal number. For example: `experience-spec@VDC-001#VIS-001`. Plain ASCII characters are required. A revision-only reference does not substitute for a
decision reference.

An initial or revised contract stays at `draft` until it is complete and internally consistent, then moves to `awaiting-approval`. If any approved Visual Direction Contract decision changes, create a new `VDC-NNN` revision, return the artifact to `draft`, complete consistency and validation checks,
and then return it to `awaiting-approval` for explicit human approval. All downstream references to the superseded revision are stale and block UI planning or implementation until the new revision is approved and the references are updated.

### 3. Journeys

Describe the core user journeys in order of importance.

For each journey include:

- journey ID;
- actor;
- trigger;
- goal;
- preconditions;
- main steps;
- alternate paths;
- failure and recovery paths;
- completion signal;
- linked requirement IDs.

### 4. Information Architecture

Define:

- major views and subviews;
- navigation model;
- entry points and return paths;
- content grouping;
- terminology and labels;
- role-based differences, if any;
- deep links or cross-links that matter to the journey.

#### Multi-View Navigation & Anti-Monolith Page Stacking Rules (Web & Mobile):

1. **Anti-Monolith Page Stacking Prohibition:** Applications across both web and mobile must never be structured as an endless single-scroll catch-all page where unrelated user journeys and feature sections are stacked vertically. Provide distinct navigation views (for web: tabs, distinct routes,
   drawers/modals; for mobile: bottom navigation bars, screen stacks, and bottom sheets).
2. **Core Journey vs. Add-On Separation:** The primary customer conversion flow (e.g. core product/service purchase, booking, order, or subscription) must remain streamlined and frictionless. Optional cross-sells, upsells, and add-ons (such as optional items, accessories, or complementary services)
   must NEVER be placed as mandatory scroll hurdles in the path of the primary conversion. Add-ons must be accessible via dedicated tabs, non-blocking summaries, or contextual opt-in drawer/modal/sheet steps with an immediate 1-click completion option for the core service.
3. **Role Surface Isolation:** Privileged operational surfaces (such as staff cashier consoles, admin management panels, or inventory controls) must have dedicated, isolated views/routes/tabs separate from customer-facing discovery and transaction surfaces.
4. **Mobile Navigation Paradigms (When targeting mobile):** Use standard mobile interaction patterns: thumb-friendly bottom navigation, screen stack transitions with intuitive back navigation, modal bottom sheets for secondary actions, touch targets of at least 44x44 points, and safe-area compliance
   (notches, navigation bars).

### 5. Screen Inventory

List every screen or view needed to cover the approved brief.

For each screen include:

- screen ID and name;
- purpose;
- linked journeys;
- linked requirement IDs;
- key content blocks;
- primary action;
- secondary actions;
- notes on reuse or variation.

### 6. State Coverage

For every important screen or flow, define:

- happy state;
- loading state;
- empty state;
- error state;
- permission state;
- destructive or high-impact confirmation state.

State notes should say what the user sees, what the user can do next, and how the experience recovers.

### 7. Responsive Behavior

State how the experience changes across supported sizes.

Include:

- minimum supported viewport;
- what stays visible first;
- what collapses or reflows;
- how tables, dense content, and side panels behave;
- how touch and pointer use differ where relevant;
- how long content and zoom affect layout.

### 8. Content Rules

Set rules for the content that appears in the experience.

Cover:

- tone and voice;
- title length and label style;
- empty-state copy;
- error-message style;
- permission copy;
- destructive-action copy;
- formatting for names, numbers, dates, and counts;
- handling for long, missing, or partial content.

### 9. Accessibility

Write accessibility guidance with a WCAG mindset.

Include:

- target standard, usually WCAG 2.2 AA if that is the project baseline;
- semantic structure and reading order;
- keyboard support for every critical action;
- focus order and focus return;
- visible focus treatment;
- non-color status cues;
- announcements for dynamic updates;
- reduced-motion behavior;
- touch target and spacing expectations;
- any known screen reader concerns.

Do not claim compliance unless the project has agreed verification evidence.

### 10. Prototype Or Full-Stack Experience Expectations

Describe the appropriate review surface for the confirmed readiness target and architecture shape.

For a confirmed prototype, keep it to:

- the minimum screens needed to review the journeys;
- realistic sample content;
- simple state switching or scenario notes;
- no production API calls;
- no production auth logic;
- no framework choice;
- no deployment plan.

State the prototype's demo limitations and that it is not production full-stack delivery. For a confirmed full-stack application, define the journeys and states that depend on backend API results, persistent or shared data, authentication and authorization, and real payment outcomes when they are in
scope. For authenticated work, include login failure, expired-session recovery, logout, User ownership denial, Staff role denial, and manual-settlement confirmation and idempotent-result states where applicable. Link each state to the accepted `FR-*` obligation so later evidence can distinguish a
completed slice from remaining original scope. This remains an experience contract, not an implementation or vendor choice.

### 11. Traceability

Map each journey and screen back to requirement IDs.

Use the requirement IDs exactly as they appear in the approved brief or source backlog.

Every important requirement should have at least one linked journey or screen.

## Handoff

```yaml
schema: fullstack-skill-handoff/v1
producing_skill: design-experience
artifact_id: experience-spec
output_path: docs/03_user_journeys.md
inputs:
    - approved product brief
    - requirement IDs from the brief
    - supporting evidence and constraints
requirement_refs:
    - approved product requirement IDs
decision_refs:
    - approved product brief
    - confirmed readiness target, architecture shape, and acceptance boundary from the product brief
    - approved Visual Direction Contract revision in VDC-NNN format
    - "exact approved visual decision references in experience-spec@VDC-NNN#VIS-NNN format"
    - named human visual approval decision for the current VDC-NNN revision
assumptions:
    - any interaction assumptions that remain visible in the spec
open_questions:
    - unresolved UX decisions that can still change the spec
risks:
    - usability, accessibility, or scope risks
validation_evidence:
    - journeys
    - screen inventory
    - state coverage
    - prototype notes
    - visual provenance, including sources, approved assets, constraints, allowed use, and comparison inputs
    - validation widths in CSS pixels and results at each width
    - visual state validation results
    - signature moment validation results
    - responsive intent validation results
    - accessibility evidence for the visual decisions
status: awaiting-approval
approval: pending
next_skills:
    - plan-delivery
```

The handoff stays experience-level. It does not add backend architecture, production implementation detail, or deployment steps, but it preserves the approved readiness target, architecture shape, and acceptance boundary for planning.

## Chat Review Protocol

Label the canonical specification with its immutable `Artifact Revision`. A Review Record is independent from handoff status and has status `pending`, `resolved`, or `superseded`. Preserve past records and allow only one active request across the lifecycle. It binds request ID, canonical path,
content revision, exact question, simplified options (`Yes`, `No`, and `Other` for user typing/comments), prompt evidence, and the source user reply or decision evidence.

Use native `ask_question` only when the host exposes it with its actual schema; otherwise ask: `Review docs/03_user_journeys.md@[revision]. Approve this exact content?` Options are `Yes` (approve), `No` (reject and pause), and `Revision` (meaningful freeform feedback). A direct Yes or No is valid
only for this unchanged shown question and needs no path, revision, or host ID. Stale, duplicate, summary, unrelated, or host replies have no effect. On resume, re-read the specification and show the bound pending question once.

Yes resolves the record and updates only closed governance metadata to approved. No resolves it as rejected and waits for an explicit user request to revise. Comments or feedback entered via `Other` (or user typing) without meaningful content ask only for clarifying feedback; sufficient feedback
sets the artifact to `draft` and routes to this owner. A substantive revision supersedes the old record, creates a new Artifact Revision, invalidates affected approvals, and asks again only after the revised specification returns to `awaiting-approval`. Do not intentionally create, update, or open
`implementation_plan.md`, editor tabs, or `RequestFeedback` metadata. Native host presentations are not approval evidence, and host-mandated opening cannot be controlled by this plugin.

## Completion Criteria

The task is complete when all of these are true:

- the product brief is approved and cited;
- the confirmed readiness target, architecture shape, and acceptance boundary are cited, with prototype demo limitations or full-stack state coverage reflected in the experience;
- the Visual Direction Contract has a unique `VDC-NNN` revision, a named human approval owner, a direction mode, product-specific rationale, provenance, validation widths, and complete unique `VIS-NNN` decisions;
- every visual decision defines all required visual-system fields, states, a signature moment, and rejected defaults with product-specific reasons;
- visual validation covers the product-approved widths, or 375, 768, and 1280 CSS px when none exist;
- journeys are defined with triggers, steps, recovery, and completion;
- information architecture and screen inventory are complete;
- state coverage includes happy, loading, empty, error, permission, and destructive cases;
- responsive behavior, content rules, and accessibility guidance are written;
- traceability covers the relevant requirement IDs;
- the handoff `decision_refs` includes the approved VDC revision, exact canonical VIS references, and named human visual approval decision;
- the handoff `validation_evidence` includes provenance, validation widths, states, signature moment, responsive intent, and accessibility evidence;
- the output exists at `artifacts/ux/experience-spec.md`;
- the work is not self-approved.

The artifact cannot be approval-ready while the Visual Direction Contract is missing, incomplete, internally inconsistent, unvalidated, stale, or awaiting updates to downstream references.

## Quality Checks

- Does the spec stay inside the approved brief?
- Can planning use it without guessing the experience?
- Is the Visual Direction Contract complete, product-specific, internally consistent, and tied to one current `VDC-NNN` revision?
- Does every `VIS-NNN` decision contain all required fields, provenance-informed rationale, relevant states, a signature moment, and reasoned rejected defaults?
- Was visual behavior validated at every product-approved width, or at 375, 768, and 1280 CSS px when none exist?
- Are all downstream visual references current and written as `experience-spec@VDC-NNN#VIS-NNN`, with each `NNN` replaced by a three-digit decimal number?
- Does the handoff carry the approved VDC revision, exact canonical VIS references, and named visual approval decision under `decision_refs`?
- Does the handoff carry provenance, validation widths, states, signature moment, responsive intent, and accessibility evidence under `validation_evidence`?
- Has the named human visual approval owner explicitly approved the current VDC revision before UI planning proceeds?
- Are any missing requirements called out as open questions or blockers?
- Does every important screen support the stated journeys?
- Is the approval boundary clear?

If the answer to any of these is no, or if the Visual Direction Contract is incomplete or inconsistent, keep the status at `draft`, `awaiting-approval`, or `blocked` rather than `approved`.
